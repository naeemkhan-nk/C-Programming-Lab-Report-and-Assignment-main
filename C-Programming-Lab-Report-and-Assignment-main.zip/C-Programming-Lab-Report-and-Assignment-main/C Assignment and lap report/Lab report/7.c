#include <stdio.h>

int main()
{
    int P,T;
    float R,I;
    P=200,T=2,R=0.5;
    I=(P*T*R)/100;

    printf("Interest : %.2f\n",I);

    return 0;
}
